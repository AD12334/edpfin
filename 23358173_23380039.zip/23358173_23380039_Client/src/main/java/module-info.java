module com.mycompany.edpfin {
    requires javafx.controls;
    exports com.mycompany.edpfin;
}

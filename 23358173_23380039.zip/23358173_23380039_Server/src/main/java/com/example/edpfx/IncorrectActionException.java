/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.edpfx;

/**
 *
 * @author downe
 */
public class IncorrectActionException extends Exception{
    
    
    public IncorrectActionException(){
        super("Incorrect Action has been committed :( \n");
    }
}